<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="utf-8">
	<title>Главная</title>
    <link rel="stylesheet" type="text/css" href="/css/style.css" />
	<script src="../../js/js.js" type="text/javascript"></script>
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<!--	<script src="../../js/jquery-3.2.1.min.js"></script>-->
</head>
<body>
	<div class="content">
	<?php include 'application/views/'.$content_view; ?>
	</div>
	<footer>
		<div class="wrapper">
			<ul>
				<li>main</li>
				<li></li>
				<li></li>
				<li></li>
			</ul>
			<ul>
				<li>Контакты</li>
				<li>Оставить заявку</li>
			</ul>
			<ul>
				<li>80978887799</li>
			</ul>
		</div>
	</footer>

</body>
</html>